clear
echo '                    
            __   __     _____   __       __       _____    
           /\_\ /_/\  /\_____\ /\_\     /\_\     ) ___ (   
          ( ( (_) ) )( (_____/( ( (    ( ( (    / /\_/\ \  
           \ \___/ /  \ \__\   \ \_\    \ \_\  / /_/ (_\ \ 
           / / _ \ \  / /__/_  / / /__  / / /__\ \ )_/ / / 
          ( (_( )_) )( (_____\( (_____(( (_____(\ \/_\/ /  
           \/_/ \_\/  \/_____/ \/_____/ \/_____/ )_____(   
                                                 
' | lolcat
echo " "
echo "                             About"|lolcat
echo " "
echo "       🙏 Hey, there I am MUHAMMAD WASIM AKRAM (W A S I), i made this tool
  to penetrate password strength In termux, so i hope guys you
                             liked it. 😘"
echo ""
echo "                  Our channel :- Hacker wasi"| lolcat
echo " "

sleep 5.0
cd $HOME/instahack
bash instahack.sh
