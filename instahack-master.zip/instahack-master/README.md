<h1 align="center">INSTA-HACK v1.0</h1>
<p align="center">
      A new automated script for Instagram Account hackig from bruteforce
</p>

## 🔍 ***About INSTA-HACK***:

INSTA is a bash based script which is officially made to test password strength of instagram account from termux with bruteforce attack and. This tool works on both rooted Android device and Non-rooted Android device.

[![Build Status](https://img.shields.io/github/stars/noob-hackers/ighack.svg)](https://github.com/evildevill/instahack)
[![Build Status](https://img.shields.io/github/forks/noob-hackers/ighack.svg)](https://github.com/evildevill/instahack)
[![License: MIT](https://img.shields.io/github/license/noob-hackers/ighack.svg)](https://github.com/evildevill/instahack)
[![Rawsec's CyberSecurity Inventory](https://inventory.rawsec.ml/img/badges/Rawsec-inventoried-FF5050_flat.svg)](https://inventory.rawsec.ml/tools.html#instahack)
[![Stage](https://img.shields.io/badge/Release-Stable-brightgreen.svg)]()
[![Awesome](https://awesome.re/badge.svg)](https://awesome.re)

![Screenshot](https://pin.it/5e1DqqG)


### 📌 ***Insta-Hack is available for***:

* Termux

### 📌 ***Installation and usage guide***:
```
$ apt-get update -y
$ apt-get upgrade -y
$ pkg install python -y 
$ pkg install python2 -y
$ pkg install git -y
$ pip install lolcat
$ git clone https://github.com/evildevill/instahack
$ ls
$ cd instahack
$ ls
$ bash setup
$ bash instahack.sh
```
* Now you need internet connection to continue further process...

* You can select any option by clicking on your keyboard

* Note:- Don't delete any of the scripts included in core files

* Open new session and start TOR (tor) before starting the attack


### Subscribe our channel on youtube:
https://www.youtube.com/Hackerwasi

### Chekout our webite:
https://hackerwasii.blogspot.com

### Instagram: 
https://www.instagram.com/__empty254__

### Pinterest:
https://in.pinterest.com/EvilDevil

### My GitHub ID link:
https://www.github.com/evildevill

### 📢 Warning

***This tool is only for educational purpose. If you use this tool for other purposes except education we will not be responsible in such cases.***
