<p align="center">
<a href="#"><img title="succeed" src="https://img.shields.io/badge/deobfuscating-succeed-green?colorB=%23017e40&style=for-the-badge"></a>
</p>
<p align="left">
<a href="https://github.com/hax0rtahm1d"><img title="HaX0r Tahm1d" src="https://img.shields.io/badge/By-HaX0r%20Tahm1d-blue?style=for-the-badge&logo=github"></a>
</p>
<br/><br/>

# SmS-BomB
Your Own SmS BomBer...!!!
# Installation Steps..
1) apt update && apt upgrade -y

2) apt install git

3) git clone https://github.com/Bhai4You/SmS-BomB.git

4) cd SmS-BomB

5) chmod +x requirement.sh start.sh

6) bash requirement.sh

7) bash start.sh

# Note :-

Only For India.!!  
