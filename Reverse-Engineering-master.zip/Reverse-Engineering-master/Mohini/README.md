<p align="center">
<a href="#"><img title="succeed" src="https://img.shields.io/badge/deobfuscating-succeed-green?colorB=%23017e40&style=for-the-badge"></a>
</p>
<p align="left">
<a href="https://github.com/hax0rtahm1d"><img title="HaX0r Tahm1d" src="https://img.shields.io/badge/By-HaX0r%20Tahm1d-blue?style=for-the-badge&logo=github"></a>
</p>
<br/><br/>

# Mohini 
<a href="https://ibb.co/VW5HGfj"><img src="https://i.ibb.co/GvNsDzx/logo.jpg" alt="logo" border="0"></a>
<br>
# Commands
## (Copy Command & Paste in Termux)
<br>
<br>
<li>cd;apt update -y;apt upgrade -y;apt install git;git clone https://github.com/Bhai4You/Mohini;cd Mohini;chmod +x mohini.sh;bash mohini.sh
<br>
