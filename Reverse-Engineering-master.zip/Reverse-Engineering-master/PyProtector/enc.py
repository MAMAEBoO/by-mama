#Encrypted By xNot_Found
#Github : https://github.com/hatakecnk/
#Do not edit the script to avoid errors
from collections import OrderedDict
import marshal, zlib, base64
exec(marshal.loads(zlib.decompress(base64.b16decode("".join(map(chr,[int("".join(str(OrderedDict([('xNot_Found', 0), ('1', 1), ('2', 2), ('3', 3), ('4', 4), ('5', 5), ('6', 6), ('7', 7), ('8', 8), ('9', 9)])[i]) for i in x.split())) for x in
"5 5  5 6  5 7  6 7  5 6  6 8  5 3  5 5  6 8  6 8  5 5  5 1  4 9  5 1  \
5 2  5 5  4 9  5 xNot_Found  6 9  7 xNot_Found  5 7  5 3  6 9  5 2  6 \
5  7 xNot_Found  4 8  5 3  5 6  5 1  5 5  4 9  5 5  4 8  4 9  5 2  4 8\
  5 5  4 8  5 1  5 4  6 6  4 9  5 7  4 9  5 xNot_Found  5 1  5 7  5 4 \
 4 8  5 3  5 7  6 6  5 4  7 xNot_Found  5 7  5 1  6 5  5 xNot_Found  4\
 8  6 5  5 7  4 9  4 8  5 5  4 8  6 7  5 6  5 3  5 3  4 8  5 3  5 xNot\
_Found  5 7  5 xNot_Found  5 5  6 5  5 6  5 6  5 1  4 9  5 1  6 5  5 4\
  6 6  5 4  6 8  5 4  5 7  6 5  6 6  5 3  6 6  5 2  6 6  5 4  5 5  5 4\
  5 3  5 5  6 8  5 7  4 9  5 7  4 9  4 9  7 xNot_Found  6 6  5 7  4 8 \
 5 7  7 xNot_Found  5 7  5 2  6 7  6 5  5 7  4 9  6 5  5 5  7 xNot_Fou\
nd  6 7  6 5  5 5  6 5  5 7  5 1  6 7  6 9  5 2  7 xNot_Found  6 8  6 \
5  6 9  6 6  6 6  5 4  5 5  5 3  5 4  5 7  5 xNot_Found  4 8  5 3  6 5\
  4 9  5 4  6 9  5 3  5 5  6 8  6 6  5 1  6 6  6 8  5 1  6 8  5 1  6 8\
  5 1  5 1  5 1  6 8  6 6  6 6  7 xNot_Found  5 7  6 9  6 8  7 xNot_Fo\
und  5 6  6 7  4 9  6 5  5 4  4 8  5 xNot_Found  6 9  4 9  6 6  5 7  7\
 xNot_Found  6 5  7 xNot_Found  7 xNot_Found  4 9  5 7  4 9  5 5  7 xN\
ot_Found  5 3  6 5  4 8  4 8  4 8  5 xNot_Found  5 5  7 xNot_Found  4 \
9  5 4  6 6  5 2  4 8  4 9  6 9  6 5  6 6  6 5  5 7  6 7  5 6  4 9  6 \
6  5 4  4 8  5 3  5 4  4 9  4 8  5 4  6 9  6 5  4 9  5 7  6 6  4 8  6 \
5  5 6  5 7  6 9  5 6  5 3  5 5  5 4  4 9  5 4  6 7  5 xNot_Found  4 9\
  6 7  6 8  5 2  5 5  5 1  5 3  5 6  6 7  5 5  6 8  5 5  4 8  5 2  5 6\
  5 6  4 8  5 7  6 5  5 6  5 2  7 xNot_Found  5 6  5 xNot_Found  5 7  \
5 6  5 6  5 2  7 xNot_Found  6 5  4 9  5 2  5 6  5 6  5 xNot_Found  5 \
7  6 5  5 6  5 2  7 xNot_Found  5 6  5 1  5 7  5 6  5 6  5 4  7 xNot_F\
ound  6 5  4 8  6 7  5 6  5 6  4 9  5 7  6 5  5 6  6 8  6 6  6 9  4 8 \
 5 4  5 1  6 8  5 3  5 6  5 4  7 xNot_Found  6 7  6 9  5 1  6 9  7 xNo\
t_Found  6 5  5 6  5 5  4 8  5 xNot_Found  6 5  5 xNot_Found  6 8  5 7\
  6 7  6 9  5 4  4 8  5 xNot_Found  6 8  6 5  6 7  6 7  6 5  5 4  5 6 \
 5 3  5 1  5 1  5 4  5 7  6 9  4 9  5 xNot_Found  6 7  4 9  5 5  5 4  \
6 7  4 9  4 8  5 5  5 1  5 7  4 8  4 9  5 5  6 9  5 5  5 2  4 8  6 7  \
6 7  6 7  5 1  7 xNot_Found  5 7  6 6  6 7  7 xNot_Found  5 6  5 xNot_\
Found  5 6  5 3  5 3  5 7  6 9  5 6  5 5  6 6  6 7  5 1  7 xNot_Found \
 5 6  5 3  4 8  6 8  4 8  6 6  7 xNot_Found  5 6  5 7  6 9  6 7  4 9  \
5 5  5 5  4 8  6 9  6 8  7 xNot_Found  6 9  5 6  5 3  6 9  5 5  6 7  5\
 1  6 7  5 4  6 9  5 7  4 8  5 1  5 5  4 8  5 4  5 7  7 xNot_Found  4 \
9  5 6  5 6  5 1  6 7  5 3  5 5  4 9  5 6  5 1  5 2  7 xNot_Found  5 6\
  6 8  6 7  4 9  4 8  5 3  5 4  5 1  6 6  4 8  5 1  5 2  5 4  6 9  5 5\
  4 8  6 8  4 9  4 9  5 6  5 3  6 7  5 1  5 xNot_Found  4 8  5 4  5 7 \
 5 5  6 7  5 5  4 8  6 8  4 9  6 7  5 4  5 1  6 6  4 8  5 4  6 7  4 8 \
 6 7  4 8  6 5  6 9  7 xNot_Found  5 7  6 6  7 xNot_Found  5 7  5 6  6\
 5  5 1  5 4  5 5  6 5  7 xNot_Found  6 7  6 8  6 8  4 9  4 9  6 7  5 \
4  6 9  5 xNot_Found  4 9  5 2  6 8  5 2  5 2  7 xNot_Found  6 7  5 1 \
 7 xNot_Found  5 1  6 9  5 6  4 9  6 7  6 9  5 2  7 xNot_Found  6 7  5\
 3  5 7  5 1  5 6  6 6  4 8  5 xNot_Found  4 9  5 5  5 7  5 4  6 8  6 \
9  4 9  4 9  5 3  5 3  5 7  7 xNot_Found  4 8  4 8  5 xNot_Found  5 1 \
 7 xNot_Found  5 2  5 2  5 3  6 7  4 8  4 9  5 5  4 9  4 9  5 3  6 7  \
5 2  5 4  5 5  5 xNot_Found  4 8  5 1  6 9  4 8  5 5  5 3  4 9  4 8  5\
 2  6 6  4 9  4 8  6 5  6 9  5 xNot_Found  4 8  6 6  4 9  4 8  6 8  5 \
5  5 2  4 8  5 3  6 7  5 6  5 5  6 5  5 4  4 8  6 8  7 xNot_Found  5 3\
  5 1  5 1  5 xNot_Found  4 8  6 8  5 4  6 5  4 8  5 5  6 9  4 9  5 4 \
 5 2  5 2  4 8  5 7  5 5  6 9  5 2  5 4  5 5  5 2  6 9  5 4  5 2  4 8 \
 6 5  6 7  5 5  5 1  4 8  4 9  4 8  5 5  5 xNot_Found  6 5  5 5  5 1  \
5 4  4 9  4 9  6 9  6 7  5 2  4 8  5 4  4 9  5 5  5 1  6 9  4 8  5 xNo\
t_Found  7 xNot_Found  7 xNot_Found  5 1  6 7  5 6  5 6  5 2  6 8  5 1\
  5 6  6 7  5 6  5 2  4 8  7 xNot_Found  5 xNot_Found  5 6  5 5  6 9  \
5 3  6 7  7 xNot_Found  5 2  4 9  4 9  7 xNot_Found  5 7  5 3  4 8  6 \
6  6 9  4 8  6 5  5 1  5 5  6 9  4 8  4 9  7 xNot_Found  5 4  5 1  7 x\
Not_Found  5 4  5 4  5 7  5 7  5 6  5 5  5 1  6 9  4 8  5 xNot_Found  \
4 9  6 5  5 1  4 9  6 8  5 6  5 2  7 xNot_Found  5 6  6 6  5 3  6 6  5\
 6  5 6  5 5  6 9  7 xNot_Found  4 8  5 3  7 xNot_Found  6 6  6 7  5 x\
Not_Found  6 5  5 2  5 3  5 2  6 7  4 8  4 9  5 3  4 8  6 5  5 5  5 3 \
 4 8  5 3  5 2  4 9  5 1  6 9  4 9  5 xNot_Found  5 5  6 6  6 9  5 5  \
5 6  4 9  5 2  5 1  5 2  5 7  5 2  5 3  5 4  5 2  6 9  6 5  4 9  6 9  \
5 6  6 9  6 7  6 7  5 3  5 2  5 7  6 9  5 6  5 xNot_Found  5 7  5 2  5\
 3  5 xNot_Found  5 7  5 5  5 1  5 3  5 6  5 6  5 7  5 7  5 3  7 xNot_\
Found  6 6  5 4  6 8  6 8  6 7  5 6  6 8  5 6  5 2  6 6  6 7  5 6  6 5\
  6 8  5 3  6 7  5 5  5 6  4 9  5 4  6 5  5 5  5 3  5 5  5 5  5 7  6 8\
  6 6  6 6  5 2  6 9  5 2  6 6  6 5  5 7  5 6  6 9  6 6  6 7  6 6  6 6\
  6 6  6 9  6 8  6 9  5 4  5 2  5 2  5 3  6 5  5 7  4 9  4 9  5 6  5 5\
  6 9  6 6  5 xNot_Found  6 8  5 2  7 xNot_Found  5 5  5 7  4 8  5 5  \
5 5  6 9  5 xNot_Found  5 1  5 1  6 5  5 7  4 8  4 9  5 1  5 4  5 6  5\
 5  5 7  6 9  4 9  6 9  5 3  6 8  5 4  5 6  6 8  5 1  4 8  5 xNot_Foun\
d  6 8  5 4  6 8  5 6  5 2  5 1  5 xNot_Found  6 7  5 5  6 5  5 3  5 5\
  5 xNot_Found  5 xNot_Found  5 6  6 5  5 5  6 6  5 2  5 4  6 5  6 9  \
6 6  6 8  6 9  6 7  6 8  5 3  4 8  5 3  6 9  6 7  5 1  6 6  5 xNot_Fou\
nd  6 9  5 1  6 9  5 xNot_Found  6 9  5 3  5 7  5 6  5 4  6 6  6 6  5 \
2  6 7  6 7  7 xNot_Found  5 3  4 9  5 1  4 9  5 3  5 5  5 7  4 9  6 6\
  6 9  6 8  5 5  6 6  6 5  5 2  6 8  6 8  6 9  4 9  4 9  5 4  5 5  5 5\
  5 3  4 8  5 5  5 4  6 9  5 7  6 9  5 5  5 1  6 5  5 1  6 8  6 5  5 5\
  6 5  5 5  4 8  6 6  5 xNot_Found  5 2  5 2  5 4  5 xNot_Found  6 5  \
7 xNot_Found  5 6  5 7  5 xNot_Found  5 5  5 5  6 6  5 6  5 4  7 xNot_\
Found  6 7  7 xNot_Found  5 3  6 8  5 xNot_Found  5 3  5 xNot_Found  6\
 6  5 5  6 8  5 5  5 1  7 xNot_Found  5 7  5 5  5 1  6 8  5 5  5 3  6 \
8  5 xNot_Found  5 5  5 xNot_Found  7 xNot_Found  5 1  6 8  6 7  5 5  \
4 9  5 2  5 3  4 8  6 6  5 6  5 6  5 1  4 8  6 5  6 6  5 5  7 xNot_Fou\
nd  5 5  6 9  5 2  5 2  6 8  5 1  5 1  6 6  4 8  6 6  6 6  5 2  6 9  6\
 8  6 8  6 5  5 6  6 6  5 1  5 xNot_Found  5 7  6 9  5 1  5 3  6 8  6 \
8  5 2  5 xNot_Found  6 9  6 6  5 3  4 8  6 5  5 4  6 6  5 xNot_Found \
 6 9  5 3  5 5  5 6  6 7  5 3  5 4  7 xNot_Found  5 5  6 5  5 2  5 6  \
5 7  5 1  6 5  6 7  6 9  5 6  6 9  6 9  6 6  5 3  6 9  5 5  5 5  5 5  \
5 2  5 7  5 7  5 xNot_Found  5 3  6 8  5 4  6 6  4 9  4 8  5 1  5 2  6\
 5  5 xNot_Found  6 5  7 xNot_Found  5 2  5 3  5 xNot_Found  6 7  4 9 \
 5 3  6 5  5 4  6 7  5 7  5 5  6 6  5 1  4 9  5 2  4 9  6 7  5 5  5 1 \
 7 xNot_Found  5 3  5 2  5 6  5 xNot_Found  5 7  5 1  5 1  6 5  5 6  5\
 xNot_Found  5 7  6 6  7 xNot_Found  4 8  5 7  5 4  6 9  4 9  4 8  5 3\
  4 8  5 6  5 2  6 8  5 4  5 7  5 5  6 5  6 7  5 1  5 7  5 xNot_Found \
 6 9  5 5  5 1  6 5  5 3  5 xNot_Found  5 5  4 8  5 7  5 3  4 8  6 9  \
5 5  5 2  4 9  5 3  5 5  6 6  5 3  6 9  5 xNot_Found  6 7  5 2  5 2  4\
 9  5 6  5 6  5 4  5 2  5 4  4 9  6 7  5 2  6 7  4 9  5 3  7 xNot_Foun\
d  5 3  6 9  6 5  5 4  6 8  6 6  6 7  5 1  5 1  5 6  5 3  5 xNot_Found\
  5 3  6 9  5 2  5 1  5 3  4 9  6 6  5 5  5 1  5 7  6 5  6 7  5 3  7 x\
Not_Found  6 6  6 6  6 6  5 3  5 5  5 7  5 4  5 5  5 5  5 1  5 4  6 6 \
 6 9  6 8  6 7  6 9  6 5  6 8  6 5  6 8  6 8  6 6  5 4  6 6  5 7  6 6 \
 4 9  6 6  4 9  6 6  5 1  5 5  6 9  5 3  6 8  5 xNot_Found  5 6  5 5  \
5 5  6 8  4 9  5 7  5 xNot_Found  7 xNot_Found  6 8  6 6  6 5  4 9  4 \
9  5 5  6 6  5 2  4 9  6 8  4 9  6 9  7 xNot_Found  6 7  4 9  5 xNot_F\
ound  6 8  5 4  7 xNot_Found  5 5  7 xNot_Found  6 7  6 8  6 8  6 9  5\
 2  6 7  5 6  6 8  6 6  5 2  6 6  4 8  5 xNot_Found  5 xNot_Found  7 x\
Not_Found  5 7  5 xNot_Found  5 2  5 5  5 3  6 9  6 9  6 6  6 9  6 6  \
5 2  6 9  4 9  5 xNot_Found  5 1  5 5  4 9  5 1  5 xNot_Found  7 xNot_\
Found  4 8  6 7  7 xNot_Found  6 8  6 5  5 2  4 9  5 2  7 xNot_Found  \
5 7  5 2  6 5  5 7  6 9  4 9  5 7  7 xNot_Found  5 5  5 4  5 7  6 6  6\
 7  5 1  6 7  7 xNot_Found  5 5  5 5  5 5  5 4  5 3  6 5  4 8  5 5  6 \
7  7 xNot_Found  5 xNot_Found  7 xNot_Found  5 xNot_Found  5 xNot_Foun\
d  5 7  6 8  5 4  5 xNot_Found  5 7  6 8  5 3  5 1  4 8  6 8  5 1  4 8\
  5 4  6 9  5 7  5 3  5 3  5 6  6 5  5 4  5 xNot_Found  5 2  7 xNot_Fo\
und  6 7  5 6  6 8  5 xNot_Found  5 4  6 9  7 xNot_Found  4 8  5 4  7 \
xNot_Found  5 1  5 7  7 xNot_Found  7 xNot_Found  6 6  6 9  5 3  5 7  \
4 9  5 7  5 xNot_Found  7 xNot_Found  5 xNot_Found  5 4  5 3  5 3  6 7\
  5 7  6 7  6 6  5 7  5 xNot_Found  7 xNot_Found  4 9  7 xNot_Found  5\
 xNot_Found  5 7  5 5  4 8  5 7  5 1  6 6  7 xNot_Found  5 5  6 5  6 9\
  5 7  7 xNot_Found  5 7  6 9  6 7  6 7  5 5  5 xNot_Found  5 4  6 7  \
5 4  6 8  4 8  6 9  6 9  6 9  4 8  5 4  6 7  6 6  5 2  6 8  5 7  5 4  \
5 3  6 6  5 xNot_Found  6 7  5 4  7 xNot_Found  6 6  4 8  6 6  6 7  6 \
7  5 7  7 xNot_Found  5 xNot_Found  4 9  5 4  6 7  6 6  6 8  6 6  5 xN\
ot_Found  6 7  6 9  7 xNot_Found  6 6  4 8  7 xNot_Found  6 7  5 3  6 \
6  7 xNot_Found  4 8  5 xNot_Found  6 8  6 7  6 5  4 8  5 4  4 9  4 9 \
 5 xNot_Found  7 xNot_Found  5 3  5 3  5 xNot_Found  5 7  6 9  5 5  4 \
9  7 xNot_Found  4 9  5 xNot_Found  7 xNot_Found  5 7  5 1  6 9  5 xNo\
t_Found  5 1  6 9  5 6  4 8  4 8  7 xNot_Found  5 4  5 xNot_Found  6 8\
  5 3  6 5  5 7  5 xNot_Found  5 2  5 6  6 6  6 6  5 5  6 8  6 6  4 8 \
 5 6  6 9  4 9  4 9  5 1  6 5  6 8  5 2  5 4  5 2  5 6  5 6  5 5  5 3 \
 5 6  5 7  5 xNot_Found  4 8  5 xNot_Found  5 4  5 2  4 8  5 4  5 3  5\
 6  5 7  5 4  5 6  5 7  4 9  5 4  5 3  7 xNot_Found  6 6  5 7  5 7  5 \
6  6 7  5 4  5 3  6 8  6 5  6 5  5 4  5 6  5 7  5 4  5 7  5 6  5 5  5 \
4  6 8  7 xNot_Found  5 4  6 5  4 8  5 xNot_Found  6 8  5 2  5 5  4 8 \
 6 6  7 xNot_Found  7 xNot_Found  5 4  5 7  5 7  4 9  5 1  6 9  6 6  5\
 7  6 7  5 xNot_Found  5 2  6 6  5 3  6 5  7 xNot_Found  5 6  6 6  5 x\
Not_Found  5 7  4 9  4 8  5 2  4 9  6 8  4 9  5 3  6 7  5 2  5 7  4 9 \
 4 8  6 7  5 6  5 6  7 xNot_Found  5 6  5 7  6 8  6 9  6 5  6 9  6 9  \
5 3  6 9  5 3  5 5  5 1  5 4  5 1  6 7  5 6  6 7  6 9  5 6  5 3  4 9  \
6 8  6 7  5 2  6 8  5 7  6 7  6 7  6 9  4 9  4 9  5 4  5 4  5 2  5 6  \
6 9  5 2  5 4  5 6  5 xNot_Found  6 6  5 4  5 5  7 xNot_Found  5 5  6 \
7  5 6  5 4  5 7  6 7  5 2  6 8  4 9  5 4  6 6  5 1  7 xNot_Found  5 3\
  4 9  5 2  4 9  6 8  5 2  5 5  5 2  6 6  6 7  6 7  5 6  4 8  5 7  6 5\
  5 xNot_Found  5 2  6 9  5 3  5 5  6 5  5 3  6 5  6 8  5 xNot_Found  \
6 5  5 xNot_Found  5 4  5 3  5 3  6 8  6 7  5 3  5 3  5 2  5 1  5 7  6\
 8  6 9  6 8  5 1  6 7  5 2  6 7  5 5  6 7  5 5  5 2  5 xNot_Found  5 \
4  5 7  6 7  5 4  7 xNot_Found  5 6  6 9  5 1  4 8  6 6  5 6  5 xNot_F\
ound  5 1  4 8  5 2  5 2  4 9  6 7  5 7  6 6  5 6  4 9  5 4  7 xNot_Fo\
und  4 8  4 8  5 xNot_Found  5 3  7 xNot_Found  5 3  6 6  5 4  5 1  5 \
1  5 5  5 4  6 5  4 9  6 5  6 7  6 6  5 6  5 7  7 xNot_Found  7 xNot_F\
ound  5 4  5 1  5 1  5 5  5 2  4 8  5 7  5 xNot_Found  5 3  4 9  5 2  \
5 2  4 8  4 9  5 xNot_Found  6 8  6 6  7 xNot_Found  6 8  6 8  5 7  4 \
9  5 7  7 xNot_Found  4 9  4 8  4 9  5 1  7 xNot_Found  4 9  5 1  4 8 \
 5 xNot_Found  5 5  6 9  5 5  4 9  5 xNot_Found  5 5  5 7  6 5  4 9  6\
 5  7 xNot_Found  6 6  6 8  6 7  5 2  5 5  5 xNot_Found  5 7  6 5  6 6\
  6 8  6 9  5 6  5 7  4 9  6 9  5 3  5 xNot_Found  5 xNot_Found  5 3  \
5 4  6 7  6 7  5 xNot_Found  5 2  6 8  6 9  6 9  6 8  5 3  4 9  5 xNot\
_Found  5 2  5 7  5 xNot_Found  6 9  4 9  5 7  4 9  6 6  6 7  6 5  5 2\
  6 8  5 7  7 xNot_Found  4 9  4 9  5 xNot_Found  6 9  5 7  5 xNot_Fou\
nd  6 6  6 7  6 5  6 5  6 7  4 8  5 5  5 2  5 7  6 6  5 1  4 9  6 6  7\
 xNot_Found  6 5  5 7  4 9  7 xNot_Found  6 5  5 6  4 9  5 1  5 2  5 6\
  5 7  5 1  6 5  5 2  6 8  6 9  6 8  5 2  5 xNot_Found  6 6  5 6  5 7 \
 6 9  5 3  4 9  7 xNot_Found  5 1  5 4  6 7  5 7  6 9  5 xNot_Found  5\
 3  5 3  6 8  5 7  7 xNot_Found  5 4  5 7  5 6  6 9  6 6  6 6  5 3  4 \
9  5 7  6 6  6 8  5 2  5 1  5 2  5 5  5 6  5 6  6 9  6 6  5 6  6 6  4 \
9  5 3  6 7  6 5  6 9  5 7  5 4  6 5  6 6  6 8  5 3  5 1  5 xNot_Found\
  6 8  7 xNot_Found  5 5  5 6  5 7  5 3  5 6  6 6  4 8  5 2  5 xNot_Fo\
und  5 5  4 8  6 6  5 7  6 9  6 5  5 2  5 4  5 6  6 6  5 xNot_Found  6\
 8  5 1  6 5  5 2  4 9  6 6  6 6  5 7  6 9  5 7  6 7  4 8  4 9  5 5  6\
 5  5 7  6 7  6 8  5 4  5 4  6 8  5 2  5 4  5 5  5 1  5 xNot_Found  5 \
1  5 1  6 8  5 4  4 9  5 xNot_Found  6 8  6 9  4 8  6 8  5 1  5 xNot_F\
ound  6 5  5 3  5 4  5 5  4 9  5 xNot_Found  4 9  7 xNot_Found  5 2  6\
 5  5 xNot_Found  5 7  5 5  5 7  4 8  7 xNot_Found  5 7  5 6  5 7  4 8\
  7 xNot_Found  5 5  4 8  4 9  7 xNot_Found  6 9  5 6  5 1  5 1  7 xNo\
t_Found  4 8  6 6  7 xNot_Found  5 4  5 1  5 xNot_Found  5 7  5 2  4 8\
  5 7  6 6  7 xNot_Found  7 xNot_Found  4 8  5 7  6 5  6 7  5 4  4 9  \
6 7  5 3  4 8  4 9  5 7  5 5  5 6  4 8  6 6  6 8  4 8  6 6  5 5  6 9  \
4 8  6 5  6 8  4 8  5 3  7 xNot_Found  6 8  5 xNot_Found  6 7  5 1  6 \
7  6 7  5 xNot_Found  4 9  5 xNot_Found  7 xNot_Found  6 9  7 xNot_Fou\
nd  5 4  5 1  5 7  5 1  5 7  7 xNot_Found  6 5  6 7  5 2  6 9  5 1  7 \
xNot_Found  5 2  6 6  5 7  4 9  5 3  5 2  5 7  6 8  5 1  6 6  5 2  4 9\
  6 6  6 8  5 4  5 6  5 6  5 5  5 1  6 9  5 xNot_Found  5 5  5 5  6 6 \
 5 7  4 8  6 5  5 7  6 7  5 2  6 9  6 5  7 xNot_Found  5 xNot_Found  6\
 9  6 7  5 1  6 6  4 9  5 2  5 3  5 3  6 6  5 1  6 6  5 6  6 9  5 6  5\
 xNot_Found  6 8  6 9  5 5  6 5  4 9  5 4  7 xNot_Found  6 8  6 8  4 8\
  5 4  4 9  5 5  6 9  4 9  5 7  5 3  6 8  7 xNot_Found  6 7  6 8  5 1 \
 7 xNot_Found  6 5  5 1  4 9  6 5  6 6  6 6  5 5  4 8  5 2  6 9  6 5  \
6 7  6 5  5 5  5 7  7 xNot_Found  6 9  6 9  5 4  5 5  5 6  6 7  5 5  6\
 9  6 7  4 8  6 5  6 9  5 2  5 2  5 7  7 xNot_Found  5 1  5 1  7 xNot_\
Found  6 6  5 5  5 xNot_Found  6 5  4 9  5 xNot_Found  6 5  5 3  6 6  \
5 xNot_Found  4 8  6 9  5 2  5 6  4 9  6 5  5 6  6 7  5 1  5 xNot_Foun\
d  5 3  6 9  4 9  6 7  5 7  4 8  6 7  6 7  5 2  5 6  6 5  6 7  6 7  6 \
5  5 xNot_Found  5 4  5 3  6 9  5 3  5 3  5 4  6 9  5 1  5 4  6 8  6 5\
  6 5  6 5  6 5  5 7  5 3  5 1  4 9  6 6  5 1  6 9  6 5  5 1  6 7  4 9\
  5 7  5 1  5 1  5 1  7 xNot_Found  5 6  6 6  6 5  6 8  7 xNot_Found  \
7 xNot_Found  5 2  5 xNot_Found  5 1  7 xNot_Found  7 xNot_Found  6 6 \
 4 8  5 7  5 1  5 5  6 7  5 5  5 3  5 1  5 3  5 4  6 8  5 7  5 6  5 6 \
 5 2  5 6  4 8  5 6  6 8  5 4  5 6  5 1  5 xNot_Found  5 1  6 6  5 2  \
5 3  4 8  5 xNot_Found  5 6  5 7  5 7  4 9  6 8  6 5  5 6  7 xNot_Foun\
d  5 6  5 1  5 2  5 6  6 8  4 9  5 7  5 5  5 xNot_Found  5 5  5 3  6 9\
  6 8  5 2  7 xNot_Found  5 2  4 9  5 3  6 7  6 8  6 6  5 7  5 6  6 8 \
 5 xNot_Found  5 6  6 8  5 xNot_Found  5 4  6 7  4 9  5 1  6 5  5 7  5\
 1  4 8  4 9  5 5  5 5  5 6  5 xNot_Found  6 9  6 6  5 3  4 8  6 6  5 \
xNot_Found  5 2  5 7  5 4  5 3  5 xNot_Found  5 7  5 6  6 7  5 4  5 5 \
 5 2  6 5  5 1  6 5  5 6  5 1  5 3  5 3  6 5  6 8  6 8  6 9  5 6  6 7 \
 4 8  6 5  5 3  5 7  6 9  5 3  4 9  7 xNot_Found  5 1  5 2  6 5  6 8  \
6 5  4 8  5 4  4 9  6 5  6 5  6 8  6 9  6 7  5 xNot_Found  5 6  5 3  6\
 5  5 5  6 6  5 5  6 5  6 7  5 3  5 xNot_Found  6 5  5 6  6 9  6 5  4 \
8  6 7  5 4  6 9  5 xNot_Found  5 3  5 5  6 8  5 4  5 4  4 8  4 8  4 8\
  5 5  7 xNot_Found  6 9  5 4  6 9  4 8  6 9  6 9  6 8  5 1  5 1  5 xN\
ot_Found  5 2  6 9  5 5  4 9  5 1  6 5  5 4  5 4  5 1  4 8  4 9  4 9  \
5 xNot_Found  6 8  5 7  6 7  5 5  5 3  5 xNot_Found  7 xNot_Found  5 2\
  5 1  4 9  6 5  5 7  6 7  5 1  5 3  6 5  5 xNot_Found  6 6  6 5  5 1 \
 7 xNot_Found  5 2  5 7  5 4  5 6  6 9  7 xNot_Found  5 3  5 7  5 6  5\
 2  6 9  5 xNot_Found  5 xNot_Found  7 xNot_Found  4 8  6 7  5 7  4 9 \
 6 9  5 7  6 5  4 8  5 4  5 6  5 7  5 7  6 8  5 1  5 2  7 xNot_Found  \
4 8  5 1  6 5  6 6  5 4  5 6  4 9  6 5  4 8  6 7  5 4  6 6  5 1  5 4  \
5 7  6 8  4 8  4 9  5 1  6 8  6 7  6 6  4 8  5 4  6 8  5 4  5 1  6 7  \
6 9  6 7  5 4  5 2  4 8  5 6  5 3  5 7  4 9  6 7  4 8  5 4  6 6  6 8  \
7 xNot_Found  5 5  5 1  5 6  5 5  5 7  5 1  5 2  5 7  6 7  5 2  5 2  4\
 8  5 xNot_Found  6 8  5 2  6 5  6 8  6 5  5 xNot_Found  6 6  7 xNot_F\
ound  5 7  6 7  5 5  6 5  6 8  5 4  4 9  5 4  5 6  5 5  7 xNot_Found  \
4 8  5 3  5 2  5 1  5 3  5 1  6 5  4 9  6 5  6 6  5 6  6 9  6 5  4 8  \
4 8  5 2  7 xNot_Found  4 8  5 1  4 8  6 9  6 6  7 xNot_Found  6 5  6 \
6  6 8  5 3  5 5  5 5  4 9  5 xNot_Found  7 xNot_Found  6 7  5 xNot_Fo\
und  5 2  5 2  5 4  6 5  6 6  5 2  5 1  5 6  6 7  6 9  5 2  6 9  7 xNo\
t_Found  7 xNot_Found  5 6  5 3  6 5  6 8  5 7  5 6  6 9  4 9  6 5  6 \
7  5 7  5 3  4 9  6 7  5 5  5 3  4 8  6 7  4 9  5 7  4 8  4 8  5 6  6 \
9  6 7  5 7  5 3  7 xNot_Found  7 xNot_Found  6 9  6 6  5 7  5 6  6 6 \
 4 8  5 4  6 9  6 5  7 xNot_Found  5 1  6 7  5 6  6 5  5 7  6 8  5 xNo\
t_Found  5 6  5 3  5 4  5 6  6 9  5 xNot_Found  7 xNot_Found  4 8  5 x\
Not_Found  6 5  5 2  5 7  6 5  5 7  5 4  5 1  7 xNot_Found  6 7  6 5  \
5 1  6 5  6 5  7 xNot_Found  6 9  5 1  5 2  4 8  5 1  5 6  5 5  6 9  5\
 7  5 xNot_Found  6 7  5 2  5 6  5 7  6 6  5 2  7 xNot_Found  5 5  5 7\
  5 xNot_Found  5 1  5 6  5 2  5 2  5 7  5 4  5 4  6 5  6 6  5 5  7 xN\
ot_Found  6 8  4 8  5 4  6 8  5 1  5 7  6 5  4 9  5 1  5 6  5 2  5 7  \
6 8  5 1  5 6  5 3  4 9  6 7  6 9  6 7  5 6  6 9  5 7  6 7  5 3  7 xNo\
t_Found  5 4  4 8  7 xNot_Found  7 xNot_Found  6 8  5 2  5 4  6 6  4 9\
  5 3  4 8  5 xNot_Found  5 6  5 3  4 9  6 5  5 xNot_Found  4 9  5 2  \
5 2  5 1  6 5  7 xNot_Found  5 3  5 1  5 4  6 7  6 6  5 2  5 7  5 xNot\
_Found  6 9  6 6  5 xNot_Found  7 xNot_Found  5 1  4 9  5 4  5 7  4 8 \
 5 4  5 2  6 5  4 8  5 2  6 6  6 6  7 xNot_Found  5 6  6 9  5 4  7 xNo\
t_Found  5 6  5 4  5 3  7 xNot_Found  4 8  5 4  6 5  6 8  5 3  6 7  4 \
9  4 8  5 2  5 5  5 5  4 8  5 xNot_Found  5 4  5 2  5 1  6 5  6 9  5 5\
  6 6  4 8  5 xNot_Found  5 2  5 1  6 6  6 9  6 8  5 2  4 8  4 9  5 3 \
 5 3  5 5  5 3  5 5  6 6  5 3  7 xNot_Found  5 xNot_Found  4 9  4 8  5\
 7  5 3  5 5  5 4  6 9  4 9  6 7  6 8  5 5  4 9  6 7  4 9  5 1  5 4  4\
 8  6 8  4 8  5 3  6 7  5 5  5 xNot_Found  5 7  6 5  6 7  6 6  6 9  6 \
7  5 xNot_Found  5 4  5 4  5 7  6 6  6 6  7 xNot_Found  6 8  6 7  5 5 \
 4 9  6 8  6 9  5 3  6 8  5 5  5 xNot_Found  5 5  5 5  4 8  6 8  5 1  \
5 4  6 9  5 3  6 9  4 9  5 7  5 xNot_Found  5 1  5 1  5 3  4 8  5 3  6\
 6  5 4  5 4  5 3  5 3  6 5  6 6  6 7  6 7  5 1  4 8  5 5  5 7  4 8  6\
 7  6 9  6 7  4 9  6 5  5 1  5 2  5 2  5 xNot_Found  5 7  6 8  5 7  4 \
8  6 9  5 xNot_Found  5 1  6 8  5 4  5 1  6 9  5 6  5 1  6 5  5 7  5 5\
  6 6  6 5  6 6  6 9  5 4  6 7  5 3  6 7  5 xNot_Found  7 xNot_Found  \
5 7  4 8  6 9  6 6  6 6  5 5  5 7  6 7  4 9  6 8  6 8  6 5  6 8  4 9  \
6 9  5 xNot_Found  5 1  5 6  6 9  5 6  6 6  6 7  5 5  5 4  6 6  5 1  6\
 7  6 7  6 5  6 6  5 5  6 5  6 9  4 9  5 6  6 9  5 6  5 xNot_Found  5 \
7  7 xNot_Found  5 xNot_Found  6 9  5 1  7 xNot_Found  5 2  5 1  5 4  \
5 5  5 4  5 1  4 9  5 2  5 1  5 5  6 7  5 6  5 6  6 8  4 8  7 xNot_Fou\
nd  5 xNot_Found  6 9  6 8  4 8  5 xNot_Found  7 xNot_Found  5 6  5 4 \
 6 9  4 8  5 3  5 5  5 5  5 2  5 5  5 4  5 3  6 8  5 2  6 7  5 6  5 5 \
 6 7  5 2  6 7  4 8  7 xNot_Found  5 xNot_Found  5 1  6 6  5 2  6 9  6\
 7  5 2  7 xNot_Found  5 6  6 8  4 8  6 7  6 7  4 8  5 3  5 7  6 5  5 \
1  4 8  5 5  5 6  4 8  6 7  4 9  6 9  6 6  6 5  5 3  5 4  7 xNot_Found\
  6 7  5 4  4 8  5 7  6 5  5 6  6 8  5 6  6 7  5 3  5 2  5 xNot_Found \
 5 2  5 3  5 4  6 5  7 xNot_Found  5 7  4 9  6 5  5 3  5 xNot_Found  5\
 xNot_Found  4 9  5 1  5 1  7 xNot_Found  5 2  5 xNot_Found  6 9  6 5 \
 5 2  6 9  5 5  4 8  6 9  7 xNot_Found  5 4  4 9  5 xNot_Found  5 4  6\
 7  4 8  5 xNot_Found  5 1  5 2  5 xNot_Found  5 xNot_Found  5 6  5 4 \
 6 6  6 6  5 2  5 7  5 5  6 8  5 2  6 8  5 6  6 9  6 6  7 xNot_Found  \
5 xNot_Found  5 4  4 8  5 3  5 xNot_Found  6 6  5 2  4 8  6 8  5 1  6 \
9  5 5  5 7  7 xNot_Found  4 8  6 7  5 xNot_Found  5 5  6 8  7 xNot_Fo\
und  6 5  6 5  6 7  6 9  5 4  5 5  6 9  6 6  7 xNot_Found  6 5  6 8  6\
 5  5 5  5 7  6 6  6 7  6 9  5 2  5 5  5 xNot_Found  7 xNot_Found  5 6\
  4 9  7 xNot_Found  5 2  6 6  5 1  5 6  5 5  5 3  6 5  5 2  5 1  5 4 \
 6 6  7 xNot_Found  6 7  4 9  6 9  5 3  4 8  5 3  6 5  5 1  5 7  4 8  \
6 8  4 9  4 8  4 8  5 7  6 6  6 8  5 1  6 5  4 8  5 4  4 9  7 xNot_Fou\
nd  5 7  4 8  6 6  5 xNot_Found  6 7  5 7  5 xNot_Found  6 7  5 2  7 x\
Not_Found  6 5  6 7  4 9  4 9  4 8  6 6  6 8  7 xNot_Found  6 8  4 8  \
6 7  5 7  5 4  5 5  6 8  5 2  5 2  5 6  6 8  5 7  4 8  4 9  5 7  5 7  \
7 xNot_Found  5 7  5 5  5 2  4 8  5 1  5 xNot_Found  4 8  5 2  5 2  5 \
6  5 7  5 5  5 4  7 xNot_Found  5 6  4 9  4 8  7 xNot_Found  4 8  5 2 \
 5 2  6 5  7 xNot_Found  7 xNot_Found  5 1  4 9  6 9  6 6  5 1  7 xNot\
_Found  6 7  5 4  7 xNot_Found  7 xNot_Found  5 5  5 4  5 6  5 1  4 9 \
 5 4  6 6  5 4  4 8  5 1  4 9  5 4  4 9  5 7  4 8  4 8  5 6  5 5  6 9 \
 5 3  6 6  5 6  4 9  6 9  5 1  5 xNot_Found  6 7  7 xNot_Found  5 2  6\
 6  5 xNot_Found  5 5  5 2  5 2  6 5  5 3  4 8  6 6  6 7  6 7  6 9  5 \
7  4 9  5 2  6 9  7 xNot_Found  6 5  6 7  6 7  5 6  5 1  5 5  6 8  5 4\
  5 4  4 9  5 2  6 9  6 6  5 1  5 7  5 xNot_Found  5 4  6 7  6 9  5 1 \
 7 xNot_Found  5 3  6 9  5 4  5 6  5 1  5 7  6 7  5 6  6 5  4 9  5 3  \
6 5  5 xNot_Found  4 9  5 2  6 8  6 5  5 2  5 7  7 xNot_Found  5 xNot_\
Found  6 5  5 7  6 5  5 2  6 5  5 4  5 6  6 8  4 8  6 6  5 6  6 9  5 1\
  5 4  6 6  6 8  6 9  7 xNot_Found  6 7  5 xNot_Found  5 7  6 7  4 9  \
5 5  5 6  6 8  5 3  5 1  5 4  5 3  5 1  5 1  6 8  5 4  6 9  6 9  4 9  \
5 6  5 xNot_Found  5 4  5 1  6 6  6 5  7 xNot_Found  6 8  6 5  5 2  7 \
xNot_Found  6 5  6 9  6 7  6 9  7 xNot_Found  4 8  7 xNot_Found  6 5  \
6 6  5 7  5 3  6 5  5 5  5 7  6 5  5 4  6 6  4 8  6 8  5 3  6 6  5 7  \
5 2  4 8  6 8  5 xNot_Found  7 xNot_Found  6 9  5 6  4 9  4 8  4 8  6 \
7  6 6  4 9  4 9  6 7  5 6  5 6  5 xNot_Found  4 9  5 6  5 5  6 5  5 2\
  6 8  6 6  5 6  4 9  4 8  6 9  5 3  5 1  7 xNot_Found  5 3  5 2  5 2 \
 5 3  6 9  5 3  5 3  5 1  5 3  7 xNot_Found  4 9  5 7  5 2  6 8  7 xNo\
t_Found  6 6  5 1  5 5  5 3  6 8  5 xNot_Found  5 4  5 6  5 5  5 6  5 \
3  6 5  5 6  6 7  6 5  6 9  4 8  6 8  6 5  5 1  5 5  5 3  4 9  5 4  6 \
9  5 4  5 xNot_Found  6 8  6 8  6 9  6 7  5 5  5 3  6 8  5 7  5 5  5 3\
  6 5  5 3  6 7  6 6  5 5  6 7  5 6  6 9  4 8  5 7  6 9  5 2  6 6  5 x\
Not_Found  4 9  4 9  6 8  5 4  4 9  4 8  4 8  5 7  6 8  4 9  5 1  6 8 \
 5 2  6 5  6 8  6 8  5 1  6 7  4 9  5 7  5 6  6 5  6 6  6 8  6 5  6 9 \
 4 8  4 9  7 xNot_Found  5 6  6 8  6 9  6 6  5 1  5 4  7 xNot_Found  5\
 2  7 xNot_Found  4 9  6 7  5 2  5 5  5 3  5 5  5 7  5 4  5 5  5 5  5 \
5  5 3  6 8  6 7  6 8  5 1  6 8  5 3  5 6  5 xNot_Found  5 3  5 7  6 6\
  5 4  7 xNot_Found  5 3  5 6  6 8  5 4  5 3  5 6  5 1  6 9  5 4  5 5 \
 7 xNot_Found  5 7  5 xNot_Found  7 xNot_Found  5 5  5 4  5 5  5 1  6 \
7  5 6  7 xNot_Found  6 6  5 2  6 5  6 9  6 8  5 3  5 xNot_Found  5 7 \
 6 5  5 4  6 5  4 9  5 3  5 1  6 7  5 3  5 6  5 4  6 7  4 9  5 1  7 xN\
ot_Found  6 6  6 8  5 2  6 9  5 6  5 1  7 xNot_Found  5 2  5 5  6 5  6\
 8  5 2  5 2  5 xNot_Found  5 xNot_Found  5 1  7 xNot_Found  6 7  5 6 \
 5 1  5 xNot_Found  4 8  6 5  5 4  5 1  6 9  6 8  5 1  6 9  5 7  5 6  \
5 4  5 1  5 6  5 5  6 9  6 6  6 8  5 xNot_Found  5 1  4 9  4 8  5 2  4\
 8  5 5  6 5  4 8  5 4  7 xNot_Found  6 5  5 xNot_Found  5 1  5 1  5 6\
  5 2  5 2  6 9  5 2  7 xNot_Found  5 1  6 9  4 8  4 8  5 7  4 9  5 4 \
 7 xNot_Found  5 5  6 8  5 5  5 xNot_Found  4 9  5 7  5 6  5 4  6 9  4\
 8  5 2  5 2  4 9  6 7  6 7  5 6  6 7  4 9  7 xNot_Found  6 8  5 1  4 \
8  4 9  5 4  6 8  6 8  6 6  5 4  7 xNot_Found  7 xNot_Found  4 9  5 3 \
 5 2  6 8  5 2  5 5  5 1  6 9  6 5  5 xNot_Found  5 3  5 2  6 6  4 9  \
6 9  5 4  7 xNot_Found  4 8  5 7  6 9  4 9  6 7  6 6  5 7  5 4  5 5  5\
 2  5 4  6 9  6 9  4 8  5 3  5 4  6 6  5 5  5 7  5 5  4 8  5 xNot_Foun\
d  7 xNot_Found  5 3  6 5  5 3  5 7  6 7  6 6  6 6  5 4  5 4  5 4  6 5\
  6 8  5 7  6 7  5 5  5 3  5 6  5 3  6 5  6 7  6 5  5 4  7 xNot_Found \
 4 8  6 8  5 6  5 1  4 9  5 1  4 9  5 7  5 1  5 1  6 6  5 6  6 8  5 3 \
 5 4  7 xNot_Found  7 xNot_Found  4 8  5 1  4 8  4 8  6 5  5 3  4 9  6\
 9  5 3  5 1"
.split("  ")]))))))