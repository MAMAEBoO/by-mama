

clear

apt update
apt upgrade
chmod +x /data/data/com.termux/files/home/tmvenom/core/run
chmod +x /data/data/com.termux/files/home/tmvenom/core/run2
chmod +x /data/data/com.termux/files/home/tmvenom/tmvenom.py
chmod +x /data/data/com.termux/files/home/tmvenom/tmvenom2.py
apt install python2
apt install curl
apt install perl
apt install ruby
gem install lolcat
pip install requests
pip2 install requests
pip install colorama
pip2 install colorama

