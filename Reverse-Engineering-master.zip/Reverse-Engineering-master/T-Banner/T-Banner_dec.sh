apt update
apt upgrade -y
apt install figlet -y
apt install toilet -y
apt install cowsay -y
apt install ruby -y
apt install nano -y
gem install lolcat
cd $HOME
cd T-Banner
cd logo
cat "T-Banner.txt" >> /data/data/com.termux/files/usr/etc/bash.bashrc
