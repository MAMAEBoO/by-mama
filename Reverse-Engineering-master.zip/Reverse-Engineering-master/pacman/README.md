<p align="center">
<a href="#"><img title="succeed" src="https://img.shields.io/badge/deobfuscating-succeed-green?colorB=%23017e40&style=for-the-badge"></a>
</p>
<p align="left">
<a href="https://github.com/hax0rtahm1d"><img title="HaX0r Tahm1d" src="https://img.shields.io/badge/By-HaX0r%20Tahm1d-blue?style=for-the-badge&logo=github"></a>
</p>
<br/><br/>

# pacman
New Fb Cloning Commands PACMAN-Bolt
>>Features:
>>Friendlist cloning
>>Target bruteforce
>>Pakistan , india ,usa passlist included

>>>USE OLD VERISON OF TERMUX IF YOU FACE ANY LOGIN PROBLEM

apt update

apt upgrade

apt install python python2 git -y

pip2 install requests mechanize

git https://github.com/faizanwahla/pacman.git

cd pacman

python2 bolt
