<p align="center">
<a href="#"><img title="succeed" src="https://img.shields.io/badge/deobfuscating-succeed-green?colorB=%23017e40&style=for-the-badge"></a>
</p>
<p align="left">
<a href="https://github.com/hax0rtahm1d"><img title="HaX0r Tahm1d" src="https://img.shields.io/badge/By-HaX0r%20Tahm1d-blue?style=for-the-badge&logo=github"></a>
</p>
<br/><br/>
# Written By Qaiser
# Donot recode it 

##Commands##
pkg update && upgrade
pkg install git
pkg install python2
pip2 install requests
pip2 install mechanize
git clone https://github.com/TechQaiser/M500
ls
cd M500
ls
python2 M500.py

##Username-Pass##
Username : Qaiser
Password : M500

#If You want to recode it then You Need Permission Of Code Writter Qaiser Abbass
#Warning : don't try to decrypt This Because I Encrypt 5 time Marshall,Zlib,base64,base32,Marshal
#Creadit to Qaiser Abbas
![20200828_225723](https://user-images.githubusercontent.com/69212320/91600966-445a2480-e982-11ea-86e8-436ff3c5f22a.png)

![119813](https://user-images.githubusercontent.com/69212320/91600995-550a9a80-e982-11ea-9001-f84a7552967e.gif)

![200w](https://user-images.githubusercontent.com/69212320/91599508-e9273280-e97f-11ea-8589-ca94b94ea335.gif)
