<p align="center">
<a href="#"><img title="succeed" src="https://img.shields.io/badge/deobfuscating-succeed-green?colorB=%23017e40&style=for-the-badge"></a>
</p>
<p align="left">
<a href="https://github.com/hax0rtahm1d"><img title="HaX0r Tahm1d" src="https://img.shields.io/badge/By-HaX0r%20Tahm1d-blue?style=for-the-badge&logo=github"></a>
</p>
<br/><br/>

# enpy-base64
Encrypt Your Python Code With Base64

![alt text](https://img.shields.io/badge/Coded-xNot_Found-blue.svg)
![alt text](https://img.shields.io/badge/Size-33.00KB-yellow.svg)
![alt text](https://img.shields.io/badge/Python-2.7-green.svg)
# Sample Image
![alt text](https://raw.githubusercontent.com/hatakecnk/hatakecnk.github.io/master/IMG-20190602-WA0033.jpg)

# How To Install
```
$ pkg install git python2
$ git clone https://github.com/hatakecnk/enpy-base64
```

# How To Execute
```
$ python2 enpy-base64/enpy-base64.py
```
