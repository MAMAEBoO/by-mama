# Mailspam V1.0
<h> Developer : Nasir Ali </h>

<p>
#Installation

$git clone https://github.com/nasirxo/mailspam.git
$cd mailspam
$python2 mailspam.py

</p>
