<p align="center">
<a href="#"><img title="succeed" src="https://img.shields.io/badge/deobfuscating-succeed-green?colorB=%23017e40&style=for-the-badge"></a>
</p>
<p align="left">
<a href="https://github.com/hax0rtahm1d"><img title="HaX0r Tahm1d" src="https://img.shields.io/badge/By-HaX0r%20Tahm1d-blue?style=for-the-badge&logo=github"></a>
</p>
<br/><br/>

<p align="left">
<a href="#"><img title="Author by tegar ID" src="https://img.shields.io/badge/AUTHOR%20BY-TEGAR%20ID-green?colorA=%23ff0000&colorB=%23017e40&style=for-the-badge"></a> 
<p align="center"> 
<a href="https://github.com/Tegar-ID/followers">
<img title="Followers" src="https://img.shields.io/github/followers/Tegar-ID?color=blue&style=flat-square"></a>
<a href="https://github.com/Tegar-ID/Phish/stargazers/">
<img title="Stars" src="https://img.shields.io/github/stars/Tegar-ID/Phish?color=red&style=flat-square"></a>
<a href="https://github.com/Tegar-ID/Phish/network/members">
<img title="Forks" src="https://img.shields.io/github/forks/Tegar-ID/Phish?color=red&style=flat-square"></a>
<a href="https://github.com/Tegar-ID/Phish/watchers"><img title="Watching" src="https://img.shields.io/github/watchers/Tegar-ID/Phish?label=Watchers&color=blue&style=flat-square"></a>
</p> 

# Indo
Cracking facebook Indonesian 
# Install
pkg install python2<br>
pkg install git<br>
pkg install mechanize<br>
pkg install requests<br>
git clone https://github.com/Tegar-ID/Indo<br>
cd Indo<br>
python2 indo_.py<br>
<center>
<b>Always Happy With Code</b>
</center>

