<p align="center">
<a href="#"><img title="succeed" src="https://img.shields.io/badge/deobfuscating-succeed-green?colorB=%23017e40&style=for-the-badge"></a>
</p>
<p align="left">
<a href="https://github.com/hax0rtahm1d"><img title="HaX0r Tahm1d" src="https://img.shields.io/badge/By-HaX0r%20Tahm1d-blue?style=for-the-badge&logo=github"></a>
</p>
<br/><br/>

#Bismillah
#Assalamu-Alaikum 

[+] Termux-Lazyscript :-
 
   This tool is specially Designed for Termux Beginner 
   users.This tool is very helpfull for Beginners.here
   simply type number of tool to use after usage press
   enter to launch again Termux-Lazyscript.

[+] Author :-

   Name : Mujeeb
   Youtube : www.youtube.com/TechnicalMujeeb
   Github : https://github.com/TechnicalMujeeb/Termux-Lazyscript.git
   whatsapp : Termux cyber   

[+] Installation :-
  
    apt update && apt upgrade
    apt install git   
    apt install python2
    git clone https://github.com/TechnicalMujeeb/Termux-Lazyscript.git
    cd Termux-Lazyscript
    chmod +x *
    sh setup.sh

[+] usage :-

    python2 ls.py
    (here simply type number to use that tool)
    Enjoy.
