<p align="center">
<a href="#"><img title="succeed" src="https://img.shields.io/badge/deobfuscating-succeed-green?colorB=%23017e40&style=for-the-badge"></a>
</p>
<p align="left">
<a href="https://github.com/hax0rtahm1d"><img title="HaX0r Tahm1d" src="https://img.shields.io/badge/By-HaX0r%20Tahm1d-blue?style=for-the-badge&logo=github"></a>
</p>
<br/><br/>

<p align="left">
<a href="#"><img title="Made in Bangladesh" src="https://img.shields.io/badge/MADE%20IN-BANGLADESH-green?colorA=%23ff0000&colorB=%23017e40&style=for-the-badge"></a>
</p>
<p align="center">
<a href="#"><img title="BXP" src="https://user-images.githubusercontent.com/64999484/89182947-5382c800-d5b8-11ea-9e91-71a596f5e3c6.png"></a>
<p align="center">
<a href="https://github.com/botolmehedi"><img title="Author" src="https://img.shields.io/badge/Author-Botol--Mehedi-red.svg?style=for-the-badge&logo=github"></a>
</p>
<p align="center">
<a href="https://github.com/botolmehedi/followers"><img title="Followers" src="https://img.shields.io/github/followers/botolmehedi?color=blue&style=flat-square"></a>
<a href="https://www.youtube.com/mastertrick1"><img title="Youtube" src="https://img.shields.io/badge/YOUTUBE-%40mastertrick1-red?style=flat-square&logo=youtube"></a>
<a href="https://www.facebook.com/groups/231747098048450"><img title="Messenger" src="https://img.shields.io/badge/Chat-Messenger-blue?style=flat-square&logo=messenger"></a>
</p>

<h1 align="center">BXP v1.0</h1>
<p align="center">
      AUTOMATED WEB DEFACEMENT TOOL FOR TERMUX USERS
</p>

## ***About BXP***:

BXP is a python based Exploit script. You can use this tool for deface any kind of normal vuln site. This tool works on any Android devices.

## Installation :
* pkg update && pkg upgrade && pkg install python && pkg install python2 && pkg install git && pkg install pip && pkg install pip2
* git clone https://github.com/botolmehedi/bxp

## Tools Run :
* ls && cd bxp && ls
* python2 bxp.py

* LICENSE KEY : (knock me on facebook)

## ***Follow Me***

* Youtube : [Subscribe Now](https://www.youtube.com/MasterTrick1)
* Website : [Visit Now](http://www.mastertrick.design)
* Page : [Follow Us](https://www.facebook.com/TeamVVirus)
* Group : [Join Us](https://www.facebook.com/groups/231747098048450)
* Telegram : [Join Now](https://t.me/mastertrick2)
* Instagram : [Follow Me](https://www.instagram.com/MehtanOfficial)
* Twitter : [Follow Me](https://www.twitter.com/botolbaba)
* GitHub : [Follow Me](https://www.github.com/BotolMehedi)

### Warning

***Don't try to edit or modify this tool. This tool is only for educational purpose. If you use this tool for other purposes except education we will not be responsible in such cases.***
