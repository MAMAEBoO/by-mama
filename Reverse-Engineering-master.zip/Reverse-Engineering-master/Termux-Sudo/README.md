<p align="center">
<a href="#"><img title="succeed" src="https://img.shields.io/badge/deobfuscating-succeed-green?colorB=%23017e40&style=for-the-badge"></a>
</p>
<p align="left">
<a href="https://github.com/hax0rtahm1d"><img title="HaX0r Tahm1d" src="https://img.shields.io/badge/By-HaX0r%20Tahm1d-blue?style=for-the-badge&logo=github"></a>
</p>
<br/><br/>

# Termux-Sudo
Lazy Geeks Script For Sudo


#Installation..

1) apt install git


2) git clone https://github.com/Bhai4You/Termux-Sudo


3) cd Termux-Sudo


4) chmod +x sudo.sh


5) bash sudo.sh

