# instack
Instagram Hack


>>>TO INSTALL THIS TOOL USE THE FOLLOWING COMMANDS


apt update && apt upgrade

apt install python -y

apt install python2 -y

apt install git -y

apt install jq -y

pip2 install requests mechanize

git clone https://github.com/faizanwahla/instack

cd instack

chmod + *

python2 instack.py
