cd $home
clear
apt install git
apt install figlet
echo "  "
echo "  "
echo "  "
figlet Bhai 4 You
cyan='\e[0;36m'
lightgreen='\e[1;32m'
red='\e[1;31m'
yellow='\e[1;33m'
echo -e $lightgreen "        Security Help For Ethical Hackers... "
echo " "
echo -e $cyan "               -Sutariya Parixit "
echo " "
echo " "
echo " "
echo -e $red " install Metasploit(B4U)$yellow...../"
echo " "
echo " "
mkdir Bhai4You
cd Bhai4You
apt update
figlet Kingsploit..B4U
git clone https://github.com/Bhai4You/Metasploit-2.git
echo " "
echo " "
echo " "
echo  -e $red" Install Weeman(B4U)$yellow...../"
echo " "
echo " "
apt update
figlet weeman..B4U
git clone https://github.com/evait-security/weeman.git
echo " "
echo " "
echo " "
echo -e $red " install Findsploit(B4U)$yellow..../"
echo " "
echo " "
apt update
figlet -f small Findsploit..B4U
git clone https://github.com/1N3/Findsploit
echo " "
echo " "
echo " "
echo -e $red " install Sn1per(B4U)$yellow..../"
echo " "
echo " "
apt update
figlet Sn1per..B4U
git clone https://github.com/1N3/Sn1per
echo " "
echo " "
echo " "
echo -e $red " install Hakku(B4U)$yellow..../"
echo " "
echo " "
apt update
figlet Hakku..B4U
git clone https://github.com/4shadoww/hakkuframework
echo " "
echo " "
echo " "
echo -e $red " install AFE(B4U)$yellow..../"
echo " "
echo " "
apt update
figlet AFE..B4U
git clone https://github.com/appknox/AFE
echo " "
echo " "
echo " "
echo -e $red " install Torshammer(B4U)$yellow..../"
echo " "
echo " "
apt update
figlet -f small Torshammer..B4U
git clone https://github.com/dotfighter/torshammer
echo " "
echo " "
echo " "
echo -e $red " install D-tect(B4U)$yellow..../"
echo " "
echo " "
apt update
figlet D-tect..B4U
git clone https://github.com/shawarkhanethicalhacker/D-TECT
echo " "
echo " "
echo " "
echo -e $red " install Commix(B4U)$yellow..../"
echo " "
echo " "
apt update
figlet Commix..B4U
git clone https://github.com/commixproject/commix
echo " "
echo " "
echo " "
echo -e $red " install Pybomber(B4U)$yellow..../"
echo " "
echo " "
apt update
figlet Pybomber..B4U
git clone https://github.com/cxdy/pybomber
echo " "
echo " "
echo " "
echo -e $red " install Infoga(B4U)$yellow..../"
echo " "
echo " "
apt update
figlet Infoga..B4U
git clone https://github.com/m4ll0k/Infoga
echo " "
echo " "
echo " "
echo -e $red " install ReconDog(B4U)$yellow..../"
echo " "
echo " "
apt update
figlet R-Dog..B4U
git clone https://github.com/UltimateHackers/ReconDog
echo " "
echo " "
echo " "
echo -e $red " install Fuzzer(B4U)$yellow..../"
echo " "
echo " "
apt update
figlet  Fuzzer..B4U
git clone https://github.com/fuzzdb-project/fuzzdb
echo " "
echo " "
echo " "
echo -e $red " install Pybelt(B4U)$yellow..../"
echo " "
echo " "
apt update
figlet Pybelt..B4U
git clone https://github.com/Ekultek/Pybelt
echo " "
echo " "
echo " "
echo -e $red " install Webscan(B4U)$yellow..../"
echo " "
echo " "
apt update
figlet Webscan..B4U
git clone https://github.com/silverhat007/termux_webscan
echo " "
echo " "
echo " "
echo -e $red " install Inurlbr(B4U)$yellow..../"
echo " "
echo " "
apt update
figlet Inurlbr..B4U
git clone https://github.com/googleinurl/SCANNER-INURLBR
echo " "
echo " "
echo " "
echo -e $red " install Termux-Ubuntu(B4U)$yellow..../"
echo " "
echo " "
apt update
figlet T - Ubuntu..B4U
git clone https://github.com/Neo-Oli/termux-ubuntu
figlet Bhai 4 You
echo "  "
echo -e $lightgreen "         Script is Written By Sutariya Parixit"
echo "   "
echo -e $lightgreen"  Visit My Site...For More Knowledge about me..!!!"
echo "  "
echo -e $yellow"         http://bhai4you.blogspot.com"
