clear
apt update -y
apt upgrade -y
pkg install nodejs -y
apt install figlet -y
apt install curl -y
npm install -g bash-obfuscate
clear
