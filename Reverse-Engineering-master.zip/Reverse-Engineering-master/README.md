# Reverse Engineering

## Introduction

#### Here You can find the Tools I have Reverse Engineered ! There is no Right to Encrypt Source Code !



[![Deobfuscating](https://img.shields.io/badge/deobfuscating-succeed-green?colorB=%23017e40&style=for-the-badge)](https://gitlab.com/hax0rtahm1d)

[![Gitlab](https://img.shields.io/badge/By-HaX0r%20Tahm1d-blue?style=for-the-badge&logo=github)](https://gitlab.com/hax0rtahm1d)[![Github](https://img.shields.io/badge/Github-HTR--TECH-green?style=for-the-badge&logo=github)](https://github.com/htr-tech)[![Instagram](https://img.shields.io/badge/IG-%40tahmid.rayat-red?style=for-the-badge&logo=instagram)](https://www.instagram.com/tahmid.rayat)[![Messenger](https://img.shields.io/badge/Chat-Messenger-blue?style=for-the-badge&logo=messenger)](https://m.me/tahmid.rayat.official)


> Licensed Under [Apache](https://choosealicense.com/licenses/apache-2.0/) License

> If Copy, Give me the Credits !!