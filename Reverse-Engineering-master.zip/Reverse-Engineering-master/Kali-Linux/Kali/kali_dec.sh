clear
DIRECTORY="/data/data/com.termux/files/usr/share/figlet"
if [ ! -d "$DIRECTORY" ]; then
apt update && apt install figlet
fi
figlet -f small "Basic installation"
echo
echo -e " \e[1m\e[32m---------------Sutariya Parixit \e[33m(Bhai 4 You)\e[32m-------------------\e[0m"
echo
echo
apt update
apt upgrade
apt install ruby
apt install nano
apt install figlet
apt install toilet
apt install cowsay
gem install lolcat
clear
clear
clear
figlet -f small "Arm Finder"
echo
echo  -e " \e[1m\e[32m---------------Sutariya Parixit \e[33m(Bhai 4 You)\e[32m-------------------\e[0m"
echo
echo
echo
echo -e " \e[1mNote : \e[34mAutodownload Arm Finder App in Your Phone \e[32m(Folder Name : BullAnonymous) \e[34mso After install Check Your Phone Architecture.\e[0m "
echo
echo
echo
echo -e "                 \e[1m\e[32m<=====[D\e[33mo\e[32mwnl\e[33mo\e[32mading]=====>\e[0m"
echo
echo
echo
cd /sdcard
mkdir Arm-Finder
git clone https://github.com/Bhai4You/Kali-Linux/blob/master/Arm.apk
ls
wget https://github.com/Bhai4You/Kali-Linux/blob/master/Arm.apk
echo
echo
clear
clear
clear
cowsay -f eyes "Bull Anonymous" | lolcat
figlet -f standard "   Kali  Linux " | lolcat
cyan='\e[0;36m'
lightgreen='\e[1;32m'
red='\e[1;31m'
yellow='\e[1;33m'
echo -e $lightgreen " \e[1m           Kali Linux On Android "
echo " "
echo -e $cyan "    \e[1m         -Sutariya Parixit "
echo " "
echo " "
echo " "
echo
echo -e "\e[1m \e[33mFind Your CPU Architecture Using Arm Finder App\e[32m "
echo -e "\e[1m\e[32m×\e[33m----------------------------------------------------\e[32m×\e[0m"
echo
echo
echo -e "\e[1m\e[93m1)\e[92m [arm64]   \e[0m\e[1m(64 bit)"
echo -e "\e[1m\e[93m2)\e[92m [armv8]   \e[0m\e[1m(64 bit)"
echo -e "\e[1m\e[93m3)\e[92m [arm]     \e[0m\e[1m(32 bit)"
echo -e "\e[1m\e[93m4)\e[92m [armhf]   \e[0m\e[1m(32 bit)"
echo -e "\e[1m\e[93m5)\e[92m [armv7]   \e[0m\e[1m(32 bit)"
echo -e "\e[1m\e[93m6)\e[92m Error Solution  \e[0m\e[1m(Try it When Error \e[32m[arm64]\e[0m and \e[32m[armv8]\e[0m)"
echo
echo
echo -e "\e[1mType \e[32mOnly Number\e[0m & Type \e[1m\e[32mcpu \e[0mTo know Your CPU architecture!!!
\e[1m\e[31mKali \e[33m>\e[32m"
read aarch
case $aarch in
1)
echo
echo "proot installing.........."
echo
apt install proot wget tar -y
echo
echo "<== installed Successfully ==>"
echo
echo -e "\e[1m\e[32m Kali Linux...\e[0m"
cat << "EOF"
`.
/+     -.
oy.    s/
sm+`  `hh-
`smh-  .dmo`
`sNms. .dNd/
`ys+-`   .ho-`    `omNd+`.hNmy-
--..``   /NNmdho/-mNmdo:`   /mNmd/.sNNms.
-hddddhhyymNNNNNmmmNNNNmdy+:-/mNNmh/+mNNd+`
-hNNNNNNNNNNNNNNNNNNNNNNNNNmdmNNNNmy+hNNNh/`
.-:+osyhddNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNmdNNNNmh/`
-ymNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNd+.
.+mNNNNNNNNNNNNNmmddhhhhhhhddmNNNNNNNNNNNNNNNNNNNNNNNNdo-
`-ohmNNNNNNNNNNmhs/-.````    ``.-:+ydmNNNNNNNNNNNNNNNNNNNNNms-
`-ohmNNNNNNNNNNNdo-`                   `-+ydmNNNNNNNNNNNNNNNNNNNmo.
.+shmNNNNNNNNNmo.                          ./ymNNNNNNNNNNNNNNNNNNNd:
.hNNNNNNNNm:                               -odNNNNNNNNNNNNNshNNNm+
:dNNNNNNNNN/                                  `+dNNNNNNNNNNNs-smNNNo
`smNNNNNNNNNd                                     .smNNNNNNNNNNdoodNNNs`
-hmmmNNNNNNNNs                                       /dNNNNNNNNNNNmhNNNNy.
::::oNNNNNNNNs                                        .ymNNNNNNNNNNNNNNNNm+`
yNNNNNNNNd`                                         :ymNNNNNNNNNNNNNNs-.
.NNNNNNNNNNy                                           .+hmNNNNNNNNNNNd.
oNNNNNNNNNNNy`                                            .odNNNNNNNNNNm+
`mds/dNNNNNNNNd-                                              .odNNNNNNNNNd/
`.   /NNNNNNNNNmo`                                               :hNNNNNNNNNdo.
dNNNNNNNNNNmo`                                               /dNNNNNNNNNmd/
/NNddNNNNNNNNms-                                              `yNNNNNNNNNNo
y+``:ymNNNNNNNmh+.                                            `yNNNNNNNNy`
`     -odNNNNNNNNmh+-                                          `mNNNNNd+`
`-ohmNNNNNNNmdo:.                                      .mNNmh+`
`./ydNNNNNNNmmho:.                                 `yhs/.`
`-+ydNNNNNNNmdhs/.                              ``
`-+shmNNNNNNNmhs:.
`./ohdmNNNNNmdy/.
`.-+ydmNNNNNds:`
`-+ydNNNNmh/`
./sdNNNmh/`
./ymNNmy-
-odNNm/
.omNm+
-hNm+
`sNm-
yNs
`dh
/h
`s
EOF
echo
wget https://build.nethunter.com/kalifs/kalifs-latest/kalifs-arm64-full.tar.xz
echo
proot --link2symlink tar -xf kalifs-arm64-full.tar.xz
cd kali-arm64 && echo "nameserver 8.8.8.8" > etc/resolv.conf
cd ../ && echo "proot --link2symlink -0 -r kali-arm64 -b /dev/ -b /sys/ -b /proc/ -b /data/data/com.termux/files/home -b /system -b /mnt /usr/bin/env -i HOME=/root PATH=/usr/local/sbin:/usr/local/bin:/bin:/usr/bin:/sbin:/usr/sbin:/usr/games:/usr/local/games TERM=$TERM /bin/bash --login" > startkali.sh
chmod 777 startkali.sh && termux-fix-shebang startkali.sh
echo
echo -e "\e[1mStart Kali Linux On Android by Starting New Termux Session And Just Type :\e[32mstartkali.sh"
echo
figlet -f big installed !!
;;
2)
echo
echo "proot installing.........."
echo
apt install proot wget tar -y
echo
echo "<== installed Successfully ==>"
echo
echo -e " Kali Linux On Android by Parixit \e[0m"
cat << "EOF"
`.
/+     -.
oy.    s/
sm+`  `hh-
`smh-  .dmo`
`sNms. .dNd/
`ys+-`   .ho-`    `omNd+`.hNmy-
--..``   /NNmdho/-mNmdo:`   /mNmd/.sNNms.
-hddddhhyymNNNNNmmmNNNNmdy+:-/mNNmh/+mNNd+`
-hNNNNNNNNNNNNNNNNNNNNNNNNNmdmNNNNmy+hNNNh/`
.-:+osyhddNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNmdNNNNmh/`
-ymNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNd+.
.+mNNNNNNNNNNNNNmmddhhhhhhhddmNNNNNNNNNNNNNNNNNNNNNNNNdo-
`-ohmNNNNNNNNNNmhs/-.````    ``.-:+ydmNNNNNNNNNNNNNNNNNNNNNms-
`-ohmNNNNNNNNNNNdo-`                   `-+ydmNNNNNNNNNNNNNNNNNNNmo.
.+shmNNNNNNNNNmo.                          ./ymNNNNNNNNNNNNNNNNNNNd:
.hNNNNNNNNm:                               -odNNNNNNNNNNNNNshNNNm+
:dNNNNNNNNN/                                  `+dNNNNNNNNNNNs-smNNNo
`smNNNNNNNNNd                                     .smNNNNNNNNNNdoodNNNs`
-hmmmNNNNNNNNs                                       /dNNNNNNNNNNNmhNNNNy.
::::oNNNNNNNNs                                        .ymNNNNNNNNNNNNNNNNm+`
yNNNNNNNNd`                                         :ymNNNNNNNNNNNNNNs-.
.NNNNNNNNNNy                                           .+hmNNNNNNNNNNNd.
oNNNNNNNNNNNy`                                            .odNNNNNNNNNNm+
`mds/dNNNNNNNNd-                                              .odNNNNNNNNNd/
`.   /NNNNNNNNNmo`                                               :hNNNNNNNNNdo.
dNNNNNNNNNNmo`                                               /dNNNNNNNNNmd/
/NNddNNNNNNNNms-                                              `yNNNNNNNNNNo
y+``:ymNNNNNNNmh+.                                            `yNNNNNNNNy`
`     -odNNNNNNNNmh+-                                          `mNNNNNd+`
`-ohmNNNNNNNmdo:.                                      .mNNmh+`
`./ydNNNNNNNmmho:.                                 `yhs/.`
`-+ydNNNNNNNmdhs/.                              ``
`-+shmNNNNNNNmhs:.
`./ohdmNNNNNmdy/.
`.-+ydmNNNNNds:`
`-+ydNNNNmh/`
./sdNNNmh/`
./ymNNmy-
-odNNm/
.omNm+
-hNm+
`sNm-
yNs
`dh
/h
`s
EOF
echo
wget https://build.nethunter.com/kalifs/kalifs-latest/kalifs-arm64-full.tar.xz
echo
proot --link2symlink tar -xf kalifs-arm64-full.tar.xz
cd kali-arm64 && echo "nameserver 8.8.8.8" > etc/resolv.conf
cd ../ && echo "proot --link2symlink -0 -r kali-arm64 -b /dev/ -b /sys/ -b /proc/ -b /data/data/com.termux/files/home -b /system -b /mnt /usr/bin/env -i HOME=/root PATH=/usr/local/sbin:/usr/local/bin:/bin:/usr/bin:/sbin:/usr/sbin:/usr/games:/usr/local/games TERM=$TERM /bin/bash --login" > startkali.sh
chmod 777 startkali.sh && termux-fix-shebang startkali.sh
echo
echo -e "\e[1mStart Kali Linux On Android by Starting New Termux Session And Just Type :\e[32mstartkali.sh"
echo
figlet -f big installed !!
;;
3)
echo "proot installing..........."
echo
apt install proot wget tar -y
echo
echo "<== installed Successfully ==>"
echo
echo -e "Kali Linux On Android by Parixit\e[0m"
cat << "EOF"
`.
/+     -.
oy.    s/
sm+`  `hh-
`smh-  .dmo`
`sNms. .dNd/
`ys+-`   .ho-`    `omNd+`.hNmy-
--..``   /NNmdho/-mNmdo:`   /mNmd/.sNNms.
-hddddhhyymNNNNNmmmNNNNmdy+:-/mNNmh/+mNNd+`
-hNNNNNNNNNNNNNNNNNNNNNNNNNmdmNNNNmy+hNNNh/`
.-:+osyhddNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNmdNNNNmh/`
-ymNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNd+.
.+mNNNNNNNNNNNNNmmddhhhhhhhddmNNNNNNNNNNNNNNNNNNNNNNNNdo-
`-ohmNNNNNNNNNNmhs/-.````    ``.-:+ydmNNNNNNNNNNNNNNNNNNNNNms-
`-ohmNNNNNNNNNNNdo-`                   `-+ydmNNNNNNNNNNNNNNNNNNNmo.
.+shmNNNNNNNNNmo.                          ./ymNNNNNNNNNNNNNNNNNNNd:
.hNNNNNNNNm:                               -odNNNNNNNNNNNNNshNNNm+
:dNNNNNNNNN/                                  `+dNNNNNNNNNNNs-smNNNo
`smNNNNNNNNNd                                     .smNNNNNNNNNNdoodNNNs`
-hmmmNNNNNNNNs                                       /dNNNNNNNNNNNmhNNNNy.
::::oNNNNNNNNs                                        .ymNNNNNNNNNNNNNNNNm+`
yNNNNNNNNd`                                         :ymNNNNNNNNNNNNNNs-.
.NNNNNNNNNNy                                           .+hmNNNNNNNNNNNd.
oNNNNNNNNNNNy`                                            .odNNNNNNNNNNm+
`mds/dNNNNNNNNd-                                              .odNNNNNNNNNd/
`.   /NNNNNNNNNmo`                                               :hNNNNNNNNNdo.
dNNNNNNNNNNmo`                                               /dNNNNNNNNNmd/
/NNddNNNNNNNNms-                                              `yNNNNNNNNNNo
y+``:ymNNNNNNNmh+.                                            `yNNNNNNNNy`
`     -odNNNNNNNNmh+-                                          `mNNNNNd+`
`-ohmNNNNNNNmdo:.                                      .mNNmh+`
`./ydNNNNNNNmmho:.                                 `yhs/.`
`-+ydNNNNNNNmdhs/.                              ``
`-+shmNNNNNNNmhs:.
`./ohdmNNNNNmdy/.
`.-+ydmNNNNNds:`
`-+ydNNNNmh/`
./sdNNNmh/`
./ymNNmy-
-odNNm/
.omNm+
-hNm+
`sNm-
yNs
`dh
/h
`s
EOF
echo
wget https://build.nethunter.com/kalifs/kalifs-latest/kalifs-armhf-minimal.tar.xz
echo
proot --link2symlink tar -xf kalifs-armhf-minimal.tar.xz
cd kali-armhf && echo "nameserver 8.8.8.8" > etc/resolv.conf
cd ../ && echo "proot --link2symlink -0 -r kali-armhf -b /dev/ -b /sys/ -b /proc/ -b /data/data/com.termux/files/home -b /system -b /mnt /usr/bin/env -i HOME=/root PATH=/usr/local/sbin:/usr/local/bin:/bin:/usr/bin:/sbin:/usr/sbin:/usr/games:/usr/local/games TERM=$TERM /bin/bash --login" > startkali.sh
chmod 777 startkali.sh && termux-fix-shebang startkali.sh
echo
echo -e "\e[1mStart Kali Linux On Android by Starting New Termux Session And Just Type :\e[32mstartkali.sh"
echo
figlet -f big installed !!
;;
4)
echo "proot installing.........."
echo
apt install proot wget tar -y
echo
echo "<== installed Successfully ==>"
echo
echo -e "Kali Linux On Android By Parixit.\e[0m"
cat << "EOF"
`.
/+     -.
oy.    s/
sm+`  `hh-
`smh-  .dmo`
`sNms. .dNd/
`ys+-`   .ho-`    `omNd+`.hNmy-
--..``   /NNmdho/-mNmdo:`   /mNmd/.sNNms.
-hddddhhyymNNNNNmmmNNNNmdy+:-/mNNmh/+mNNd+`
-hNNNNNNNNNNNNNNNNNNNNNNNNNmdmNNNNmy+hNNNh/`
.-:+osyhddNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNmdNNNNmh/`
-ymNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNd+.
.+mNNNNNNNNNNNNNmmddhhhhhhhddmNNNNNNNNNNNNNNNNNNNNNNNNdo-
`-ohmNNNNNNNNNNmhs/-.````    ``.-:+ydmNNNNNNNNNNNNNNNNNNNNNms-
`-ohmNNNNNNNNNNNdo-`                   `-+ydmNNNNNNNNNNNNNNNNNNNmo.
.+shmNNNNNNNNNmo.                          ./ymNNNNNNNNNNNNNNNNNNNd:
.hNNNNNNNNm:                               -odNNNNNNNNNNNNNshNNNm+
:dNNNNNNNNN/                                  `+dNNNNNNNNNNNs-smNNNo
`smNNNNNNNNNd                                     .smNNNNNNNNNNdoodNNNs`
-hmmmNNNNNNNNs                                       /dNNNNNNNNNNNmhNNNNy.
::::oNNNNNNNNs                                        .ymNNNNNNNNNNNNNNNNm+`
yNNNNNNNNd`                                         :ymNNNNNNNNNNNNNNs-.
.NNNNNNNNNNy                                           .+hmNNNNNNNNNNNd.
oNNNNNNNNNNNy`                                            .odNNNNNNNNNNm+
`mds/dNNNNNNNNd-                                              .odNNNNNNNNNd/
`.   /NNNNNNNNNmo`                                               :hNNNNNNNNNdo.
dNNNNNNNNNNmo`                                               /dNNNNNNNNNmd/
/NNddNNNNNNNNms-                                              `yNNNNNNNNNNo
y+``:ymNNNNNNNmh+.                                            `yNNNNNNNNy`
`     -odNNNNNNNNmh+-                                          `mNNNNNd+`
`-ohmNNNNNNNmdo:.                                      .mNNmh+`
`./ydNNNNNNNmmho:.                                 `yhs/.`
`-+ydNNNNNNNmdhs/.                              ``
`-+shmNNNNNNNmhs:.
`./ohdmNNNNNmdy/.
`.-+ydmNNNNNds:`
`-+ydNNNNmh/`
./sdNNNmh/`
./ymNNmy-
-odNNm/
.omNm+
-hNm+
`sNm-
yNs
`dh
/h
`s
EOF
echo
wget https://build.nethunter.com/kalifs/kalifs-latest/kalifs-armhf-minimal.tar.xz
echo
proot --link2symlink tar -xf kalifs-armhf-minimal.tar.xz
cd kali-armhf && echo "nameserver 8.8.8.8" > etc/resolv.conf
cd ../ && echo "proot --link2symlink -0 -r kali-armhf -b /dev/ -b /sys/ -b /proc/ -b /data/data/com.termux/files/home -b /system -b /mnt /usr/bin/env -i HOME=/root PATH=/usr/local/sbin:/usr/local/bin:/bin:/usr/bin:/sbin:/usr/sbin:/usr/games:/usr/local/games TERM=$TERM /bin/bash --login" > startkali.sh
chmod 777 startkali.sh && termux-fix-shebang startkali.sh
echo
echo -e "\e[1mStart Kali Linux On Android by Starting New Termux Session And Just Type :\e[32mstartkali.sh"
echo
figlet -f installed
;;
5)
echo "proot installing.........."
echo
apt install proot wget tar -y
echo
echo "installed successfully.... :D"
echo
echo -e "Kali Linux On Android by Parixit\e[0m"
cat << "EOF"
`.
/+     -.
oy.    s/
sm+`  `hh-
`smh-  .dmo`
`sNms. .dNd/
`ys+-`   .ho-`    `omNd+`.hNmy-
--..``   /NNmdho/-mNmdo:`   /mNmd/.sNNms.
-hddddhhyymNNNNNmmmNNNNmdy+:-/mNNmh/+mNNd+`
-hNNNNNNNNNNNNNNNNNNNNNNNNNmdmNNNNmy+hNNNh/`
.-:+osyhddNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNmdNNNNmh/`
-ymNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNd+.
.+mNNNNNNNNNNNNNmmddhhhhhhhddmNNNNNNNNNNNNNNNNNNNNNNNNdo-
`-ohmNNNNNNNNNNmhs/-.````    ``.-:+ydmNNNNNNNNNNNNNNNNNNNNNms-
`-ohmNNNNNNNNNNNdo-`                   `-+ydmNNNNNNNNNNNNNNNNNNNmo.
.+shmNNNNNNNNNmo.                          ./ymNNNNNNNNNNNNNNNNNNNd:
.hNNNNNNNNm:                               -odNNNNNNNNNNNNNshNNNm+
:dNNNNNNNNN/                                  `+dNNNNNNNNNNNs-smNNNo
`smNNNNNNNNNd                                     .smNNNNNNNNNNdoodNNNs`
-hmmmNNNNNNNNs                                       /dNNNNNNNNNNNmhNNNNy.
::::oNNNNNNNNs                                        .ymNNNNNNNNNNNNNNNNm+`
yNNNNNNNNd`                                         :ymNNNNNNNNNNNNNNs-.
.NNNNNNNNNNy                                           .+hmNNNNNNNNNNNd.
oNNNNNNNNNNNy`                                            .odNNNNNNNNNNm+
`mds/dNNNNNNNNd-                                              .odNNNNNNNNNd/
`.   /NNNNNNNNNmo`                                               :hNNNNNNNNNdo.
dNNNNNNNNNNmo`                                               /dNNNNNNNNNmd/
/NNddNNNNNNNNms-                                              `yNNNNNNNNNNo
y+``:ymNNNNNNNmh+.                                            `yNNNNNNNNy`
`     -odNNNNNNNNmh+-                                          `mNNNNNd+`
`-ohmNNNNNNNmdo:.                                      .mNNmh+`
`./ydNNNNNNNmmho:.                                 `yhs/.`
`-+ydNNNNNNNmdhs/.                              ``
`-+shmNNNNNNNmhs:.
`./ohdmNNNNNmdy/.
`.-+ydmNNNNNds:`
`-+ydNNNNmh/`
./sdNNNmh/`
./ymNNmy-
-odNNm/
.omNm+
-hNm+
`sNm-
yNs
`dh
/h
`s
EOF
echo
wget https://build.nethunter.com/kalifs/kalifs-latest/kalifs-armhf-minimal.tar.xz
echo
proot --link2symlink tar -xf kalifs-armhf-minimal.tar.xz
cd kali-armhf && echo "nameserver 8.8.8.8" > etc/resolv.conf
cd ../ && echo "proot --link2symlink -0 -r kali-armhf -b /dev/ -b /sys/ -b /proc/ -b /data/data/com.termux/files/home -b /system -b /mnt /usr/bin/env -i HOME=/root PATH=/usr/local/sbin:/usr/local/bin:/bin:/usr/bin:/sbin:/usr/sbin:/usr/games:/usr/local/games TERM=$TERM /bin/bash --login" > startkali.sh
chmod 777 startkali.sh && termux-fix-shebang startkali.sh
echo
echo -e "\e[1mStart Kali Linux On Android by Starting New Termux Session And Just Type :\e[32mstartkali.sh"
echo
figlet -f installed !!
;;
6)
echo
echo "proot installing......"
echo
apt install proot wget tar -y
echo
echo "<== installed Successfully ==>"
echo
echo "Kali Linux On Android by Parixit."
echo
wget https://build.nethunter.com/kalifs/kalifs-latest/kalifs-arm64-minimal.tar.xz
echo
proot --link2symlink tar -xf kalifs-arm64-minimal.tar.xz
cd kali-arm64 && echo "nameserver 8.8.8.8" > etc/resolv.conf
cd ../ && echo "proot --link2symlink -0 -r kali-arm64 -b /dev/ -b /sys/ -b /proc/ -b /data/data/com.termux/files/home -b /system -b /mnt /usr/bin/env -i HOME=/root PATH=/usr/local/sbin:/usr/local/bin:/bin:/usr/bin:/sbin:/usr/sbin:/usr/games:/usr/local/games TERM=$TERM /bin/bash --login" > startkali.sh
chmod 777 startkali.sh && termux-fix-shebang startkali.sh
echo
echo -e "\e[1mStart Kali Linux On Android by Starting New Termux Session And Just Type :\e[32mstartkali.sh"
echo
;;
cpu)
echo
echo -e "\e[1m\e[33mYou Can install Kali Linux On Your \e[32mAndroid!!!\e[33m, Your Phone Architecture is \e[32m==>"
aarch=`dpkg --print-architecture`
if [ $aarch = "aarch64" ] ; then
echo
echo "bad luck you are using aarch64 so try your luck because it is not personally tested on aarch64..!!"
else
echo
echo $aarch
fi
;;
esac
