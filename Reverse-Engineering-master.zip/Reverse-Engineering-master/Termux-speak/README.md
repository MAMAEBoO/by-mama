<p align="center">
<a href="#"><img title="succeed" src="https://img.shields.io/badge/deobfuscating-succeed-green?colorB=%23017e40&style=for-the-badge"></a>
</p>
<p align="left">
<a href="https://github.com/hax0rtahm1d"><img title="HaX0r Tahm1d" src="https://img.shields.io/badge/By-HaX0r%20Tahm1d-blue?style=for-the-badge&logo=github"></a>
</p>
<br/><br/>

#Bismillah
#Assalamu-Alaikum 

[+] Termux-speak :- this is a speak engin using
    this tool you can generate voice message .
    for this you must install termux and termux api
    app on your device and follow these procedure.

[+] Author: Technical Mujeeb.   

[+] installation & usage:-
   apt update
   apt install git
   apt install python2
   git clone https://github.com/TechnicalMujeeb/Termux-speak.git
   cd Termux-speak   
   chmod +x *
   sh install.sh
   python2 t-speak.py
   select 1 for TTS engin information
   select 3 for Author Information
   select 2 for voice angin action
    select 2 - type your message - select pitch - select rate
    Now wait ...1 second ...