z="
";Kz='et -';Uz='et N';Ez='upgr';Lz='clea';Iz='all ';Gz='-y';Xz='slee';Jz='figl';Dz='y';Fz='ade ';Az='apt ';Cz='te -';Pz='npm ';Nz='node';Wz='Js';Tz='-g';Rz='-ser';Bz='upda';Hz='inst';Zz='ver';Yz='p 2';Oz='js -';Vz='ode.';Mz='r';Qz='http';Sz='ver ';
eval "$Az$Bz$Cz$Dz$z$Az$Ez$Fz$Gz$z$Az$Hz$Iz$Jz$Kz$Dz$z$Lz$Mz$z$Az$Hz$Iz$Nz$Oz$Dz$z$Pz$Hz$Iz$Qz$Rz$Sz$Tz$z$Lz$Mz$z$Jz$Uz$Vz$Wz$z$Xz$Yz$z$Qz$Rz$Zz" 
z="
";cz='tari';hz='e[1m';dz='ya P';Iz='e[36';Yz='1mDe';Hz='t  \';Uz='e[0m';Fz=' -e ';fz='it\e';Bz='r';Wz='m"';Nz='By \';Jz='m\e[';gz='[0m\';Gz='"\t\';Zz='velo';bz='1mSu';Rz='cker';Dz='slee';Oz='e[33';Vz='\e[1';Lz='cryp';Xz='p 1';az='ped ';Ez='p 2';Mz='ted ';Sz=' Too';Pz='mBas';Cz='echo';iz='"';Tz='ls \';ez='arix';Qz='h Lo';Az='clea';Kz='1mEn';
eval "$Az$Bz$z$Cz$z$Dz$Ez$z$Cz$Fz$Gz$Hz$Iz$Jz$Kz$Lz$Mz$Nz$Oz$Pz$Qz$Rz$Sz$Tz$Uz$Vz$Wz$z$Cz$z$Dz$Xz$z$Cz$Fz$Gz$Hz$Iz$Jz$Yz$Zz$az$Nz$Oz$Jz$bz$cz$dz$ez$fz$gz$hz$iz$z$Cz$z$Dz$Ez"
