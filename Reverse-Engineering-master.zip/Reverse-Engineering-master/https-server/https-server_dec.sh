apt update -y
apt upgrade -y
apt install figlet -y
clear
apt install nodejs -y
npm install http-server -g
clear
figlet Node.Js
sleep 2
http-server
clear
echo
sleep 2
echo -e "\t\t  \e[36m\e[1mEncrypted By \e[33mBash Locker Tools \e[0m\e[1m"
echo
sleep 1
echo -e "\t\t  \e[36m\e[1mDeveloped By \e[33m\e[1mSutariya Parixit\e[0m\e[1m"
echo
sleep 2
